--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO sky;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO sky;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO sky;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO sky;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO sky;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO sky;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE auth_user OWNER TO sky;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE auth_user_groups OWNER TO sky;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_groups_id_seq OWNER TO sky;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_id_seq OWNER TO sky;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_user_user_permissions OWNER TO sky;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_user_permissions_id_seq OWNER TO sky;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: core_analiseimage; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE core_analiseimage (
    id integer NOT NULL,
    image character varying(100) NOT NULL,
    analise_id integer NOT NULL
);


ALTER TABLE core_analiseimage OWNER TO sky;

--
-- Name: core_analiseimage_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE core_analiseimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_analiseimage_id_seq OWNER TO sky;

--
-- Name: core_analiseimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE core_analiseimage_id_seq OWNED BY core_analiseimage.id;


--
-- Name: core_analysischart; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE core_analysischart (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    title character varying(75) NOT NULL,
    description text NOT NULL
);


ALTER TABLE core_analysischart OWNER TO sky;

--
-- Name: core_analysischart_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE core_analysischart_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_analysischart_id_seq OWNER TO sky;

--
-- Name: core_analysischart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE core_analysischart_id_seq OWNED BY core_analysischart.id;


--
-- Name: core_expensesbyfunctions; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE core_expensesbyfunctions (
    id integer NOT NULL,
    period_id integer NOT NULL,
    committed numeric(30,2),
    committed_deflated numeric(30,2),
    function character varying(5) NOT NULL,
    authorized numeric(30,2)
);


ALTER TABLE core_expensesbyfunctions OWNER TO sky;

--
-- Name: core_expensesbyfunctions_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE core_expensesbyfunctions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_expensesbyfunctions_id_seq OWNER TO sky;

--
-- Name: core_expensesbyfunctions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE core_expensesbyfunctions_id_seq OWNED BY core_expensesbyfunctions.id;


--
-- Name: core_expensesbyfunctionsandorgans; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE core_expensesbyfunctionsandorgans (
    id integer NOT NULL,
    period_id integer NOT NULL,
    committed numeric(30,2),
    committed_deflated numeric(30,2),
    function character varying(5) NOT NULL,
    organ_id integer NOT NULL,
    authorized numeric(30,2)
);


ALTER TABLE core_expensesbyfunctionsandorgans OWNER TO sky;

--
-- Name: core_expensesbyfunctionsandorgans_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE core_expensesbyfunctionsandorgans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_expensesbyfunctionsandorgans_id_seq OWNER TO sky;

--
-- Name: core_expensesbyfunctionsandorgans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE core_expensesbyfunctionsandorgans_id_seq OWNED BY core_expensesbyfunctionsandorgans.id;


--
-- Name: core_expensesbysourcesofresources; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE core_expensesbysourcesofresources (
    id integer NOT NULL,
    period_id integer NOT NULL,
    committed numeric(30,2),
    committed_deflated numeric(30,2),
    source_classification character varying(5) NOT NULL,
    authorized numeric(30,2)
);


ALTER TABLE core_expensesbysourcesofresources OWNER TO sky;

--
-- Name: core_expensesbysourcesofresources_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE core_expensesbysourcesofresources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_expensesbysourcesofresources_id_seq OWNER TO sky;

--
-- Name: core_expensesbysourcesofresources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE core_expensesbysourcesofresources_id_seq OWNED BY core_expensesbysourcesofresources.id;


--
-- Name: core_governmentprogram; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE core_governmentprogram (
    id integer NOT NULL,
    committed numeric(30,2),
    committed_deflated numeric(30,2),
    authorized numeric(30,2),
    program character varying(5) NOT NULL,
    period_id integer NOT NULL
);


ALTER TABLE core_governmentprogram OWNER TO sky;

--
-- Name: core_governmentprogram_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE core_governmentprogram_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_governmentprogram_id_seq OWNER TO sky;

--
-- Name: core_governmentprogram_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE core_governmentprogram_id_seq OWNED BY core_governmentprogram.id;


--
-- Name: core_organ; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE core_organ (
    id integer NOT NULL,
    initials character varying(12) NOT NULL,
    name character varying(256) NOT NULL,
    description text NOT NULL
);


ALTER TABLE core_organ OWNER TO sky;

--
-- Name: core_organ_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE core_organ_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_organ_id_seq OWNER TO sky;

--
-- Name: core_organ_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE core_organ_id_seq OWNED BY core_organ.id;


--
-- Name: core_period; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE core_period (
    id integer NOT NULL,
    year integer NOT NULL
);


ALTER TABLE core_period OWNER TO sky;

--
-- Name: core_period_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE core_period_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_period_id_seq OWNER TO sky;

--
-- Name: core_period_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE core_period_id_seq OWNED BY core_period.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO sky;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO sky;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO sky;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO sky;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO sky;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: sky
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO sky;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sky
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: sky
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO sky;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_analiseimage ALTER COLUMN id SET DEFAULT nextval('core_analiseimage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_analysischart ALTER COLUMN id SET DEFAULT nextval('core_analysischart_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_expensesbyfunctions ALTER COLUMN id SET DEFAULT nextval('core_expensesbyfunctions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_expensesbyfunctionsandorgans ALTER COLUMN id SET DEFAULT nextval('core_expensesbyfunctionsandorgans_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_expensesbysourcesofresources ALTER COLUMN id SET DEFAULT nextval('core_expensesbysourcesofresources_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_governmentprogram ALTER COLUMN id SET DEFAULT nextval('core_governmentprogram_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_organ ALTER COLUMN id SET DEFAULT nextval('core_organ_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_period ALTER COLUMN id SET DEFAULT nextval('core_period_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: sky
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add permission	3	add_permission
8	Can change permission	3	change_permission
9	Can delete permission	3	delete_permission
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add Análise	7	add_analysischart
20	Can change Análise	7	change_analysischart
21	Can delete Análise	7	delete_analysischart
22	Can add Imagem da Análise	8	add_analiseimage
23	Can change Imagem da Análise	8	change_analiseimage
24	Can delete Imagem da Análise	8	delete_analiseimage
25	Can add Período	9	add_period
26	Can change Período	9	change_period
27	Can delete Período	9	delete_period
28	Can add Despesa por Fonte de Recurso	10	add_expensesbysourcesofresources
29	Can change Despesa por Fonte de Recurso	10	change_expensesbysourcesofresources
30	Can delete Despesa por Fonte de Recurso	10	delete_expensesbysourcesofresources
31	Can add Órgão	11	add_organ
32	Can change Órgão	11	change_organ
33	Can delete Órgão	11	delete_organ
34	Can add Despesas por Função e Órgão	12	add_expensesbyfunctionsandorgans
35	Can change Despesas por Função e Órgão	12	change_expensesbyfunctionsandorgans
36	Can delete Despesas por Função e Órgão	12	delete_expensesbyfunctionsandorgans
37	Can add Despesa por Função	13	add_expensesbyfunctions
38	Can change Despesa por Função	13	change_expensesbyfunctions
39	Can delete Despesa por Função	13	delete_expensesbyfunctions
40	Can add cors model	14	add_corsmodel
41	Can change cors model	14	change_corsmodel
42	Can delete cors model	14	delete_corsmodel
43	Can add Programa do Governo	15	add_governmentprogram
44	Can change Programa do Governo	15	change_governmentprogram
45	Can delete Programa do Governo	15	delete_governmentprogram
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('auth_permission_id_seq', 45, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$30000$qnnSkS5Ze7Tp$DzsmwcQmleJqfELA/RMLxXL+igSQxCxMEJ10BT92x5o=	2017-01-16 14:35:00.675194+00	t	sky			sky@sky.com	t	t	2017-01-12 20:54:12.914148+00
3	pbkdf2_sha256$30000$tLPHwuX8ayIM$ApD/6wd+FIRSwbgVZl6oJq9/jSDQA0bDWro7FEeVDtk=	2017-04-26 20:57:51.167669+00	t	fernanda	Fernanda	Meirelles	fernanda.meirelles@idesam.org.br	t	t	2017-01-17 16:37:44+00
2	pbkdf2_sha256$30000$rdzcAGxioRTX$iCwKc8SixOR/i2O7yst+2C752ZiAW9+Ch7JN058CTzY=	2017-04-27 13:39:28.653695+00	t	daniel	Daniel	Lins	daniel@skymarket.com.br	t	t	2017-01-16 14:35:28+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('auth_user_id_seq', 3, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: core_analiseimage; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY core_analiseimage (id, image, analise_id) FROM stdin;
1	analysis/gráficos-no-excel-tipo-de-gráfico-1024x644.png	1
2	analysis/grc3a1fico-ii.gif	1
3	analysis/screen-shot-2010-03-27-at-10-21-12.png	1
4	analysis/images.jpg	2
5	analysis/depositphotos_3989956-stock-illustration-pie-chart.jpg	2
6	analysis/grafico-barra.jpg	2
7	analysis/gráfico_001.png	3
8	analysis/allgraphscharts.png	3
9	analysis/Untitled-614.jpg	3
10	analysis/graficl.JPG	3
11	analysis/landscape.jpg	6
12	analysis/slide4.jpg	4
\.


--
-- Name: core_analiseimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('core_analiseimage_id_seq', 13, true);


--
-- Data for Name: core_analysischart; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY core_analysischart (id, created, updated, title, description) FROM stdin;
4	2017-04-04 04:02:43.184526+00	2017-04-04 04:07:12.215406+00	A Gestão Ambiental no Cenário Amazônico	aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\r\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\r\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
6	2017-04-04 04:06:31.839166+00	2017-04-04 04:16:31.539176+00	Outras Funções Orçamentárias	aaaaaaa aa aaaaa aaaaa aaaaaaa aaaaaa aaaaaaaa aaaaa aaaaaaaaa aaaaaaaaaaaa aaaa aaaaaaa aaaaaa aaaaaa aaaaaa aaaaaaaaaa aaaaaaaa aaaaaaa aaaaa aaaaa aaaaaaa aaaa aaaaaaa aaaaaaaa aaaa aaaaa aaaaaa aaaaaaa aaaa aaaaaa aaaaa aaaaaa aaaaaa aaaaaaaa aaaaaaa aaaaaaaa aaaa aaaaa aa aaaaaaa aaaaa aaaaaaa aa aaaaa aaaaa aaaaaaa aaaaaa aaaaaaaa aaaaa aaaaaaaaa aaaaaaaaaaaa aaaa aaaaaaa aaaaaa aaaaaa aaaaaa aaaaaaaaaa aaaaaaaa aaaaaaa aaaaa aaaaa aaaaaaa aaaa aaaaaaa aaaaaaaa aaaa aaaaa aaaaaa aaaaaaa aaaa aaaaaa aaaaa aaaaaa aaaaaa aaaaaaaa aaaaaaa aaaaaaaa aaaa aaaaa aa aaaaaaa aaaaa aaaaaaa aa aaaaa aaaaa aaaaaaa aaaaaa aaaaaaaa aaaaa aaaaaaaaa aaaaaaaaaaaa aaaa aaaaaaa aaaaaa aaaaaa aaaaaa aaaaaaaaaa aaaaaaaa aaaaaaa aaaaa aaaaa aaaaaaa aaaa aaaaaaa aaaaaaaa aaaa aaaaa aaaaaa aaaaaaa aaaa aaaaaa aaaaa aaaaaa aaaaaa aaaaaaaa aaaaaaa aaaaaaaa aaaa aaaaa aa aaaaaaa aaaaa aaaaaaa aa aaaaa aaaaa aaaaaaa aaaaaa aaaaaaaa aaaaa aaaaaaaaa aaaaaaaaaaaa aaaa aaaaaaa aaaaaa aaaaaa aaaaaa aaaaaaaaaa aaaaaaaa aaaaaaa aaaaa aaaaa aaaaaaa aaaa aaaaaaa aaaaaaaa aaaa aaaaa aaaaaa aaaaaaa aaaa aaaaaa aaaaa aaaaaa aaaaaa aaaaaaaa aaaaaaa aaaaaaaa aaaa aaaaa aa aaaaaaa aaaaa aaaaaaa aa aaaaa aaaaa aaaaaaa aaaaaa aaaaaaaa aaaaa aaaaaaaaa aaaaaaaaaaaa aaaa aaaaaaa aaaaaa aaaaaa aaaaaa aaaaaaaaaa aaaaaaaa aaaaaaa aaaaa aaaaa aaaaaaa aaaa aaaaaaa aaaaaaaa aaaa aaaaa aaaaaa aaaaaaa aaaa aaaaaa aaaaa aaaaaa aaaaaa aaaaaaaa aaaaaaa aaaaaaaa aaaa aaaaa aa aaaaaaa aaaaa aaaaaaa aa aaaaa aaaaa aaaaaaa aaaaaa 12
2	2017-01-17 16:34:56.86171+00	2017-04-04 04:07:18.240088+00	As Funções Executadas pelo Estado	Sed elementum tellus ac magna commodo, vel lacinia justo malesuada. Mauris lorem odio, consequat et scelerisque eget, interdum in metus. Aliquam mollis in neque vel suscipit. Proin malesuada justo quis libero posuere, a porta neque facilisis. Pellentesque feugiat purus ac arcu faucibus luctus. Quisque at tempus odio. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. In mollis, turpis ac mollis vehicula, ipsum sapien pulvinar neque, ac dictum dui libero vitae arcu. Fusce vehicula lorem enim, ut imperdiet mi vestibulum non. Aliquam ac semper nisl. Curabitur sagittis justo libero, vitae tempus erat vulputate lacinia. Etiam a massa nec velit gravida sollicitudin at sit amet est. Nullam consectetur felis iaculis mollis porttitor. Nunc sagittis lorem eu ligula porttitor, accumsan hendrerit tellus imperdiet. Nullam nec erat et dui posuere rhoncus nec vel felis.
3	2017-01-17 16:35:37.726539+00	2017-04-04 04:07:22.990551+00	Gestão Ambiental no Amazonas	Maecenas molestie nisl sit amet rhoncus luctus. Nulla porttitor vulputate quam nec egestas. Suspendisse potenti. Sed volutpat, tortor ac malesuada posuere, odio dolor accumsan sem, et vehicula nisl ipsum in erat. Proin euismod ultricies nisl eu placerat. Vivamus eget nulla quis mi congue tincidunt. Cras tincidunt dolor sit amet mauris luctus, non vulputate nibh consequat. Etiam quam dolor, consequat at volutpat ac, imperdiet nec dui. Duis varius eu diam vel consequat. Nulla in mi ac lacus pharetra maximus. Suspendisse potenti. Integer nec urna ac est rhoncus consequat. Sed tincidunt blandit volutpat. Nunc tincidunt nisl ut tincidunt lacinia.\r\n\r\nCras aliquam velit eu sapien elementum pulvinar. Nam mi eros, aliquet eget elit vel, facilisis blandit felis. Nunc vitae dolor varius, efficitur nisl at, consectetur elit. Mauris dictum fermentum leo, eu tincidunt lorem facilisis vel. Pellentesque sit amet libero eu velit auctor pretium. Nunc ac mauris quis mi accumsan blandit vel nec nibh. In id bibendum neque.
1	2017-01-17 16:33:57.301746+00	2017-04-04 04:07:28.808366+00	Orçamento do Amazonas	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla bibendum eu neque eget aliquam. Integer faucibus, felis quis sodales mollis, sapien felis sodales velit, sit amet porta nunc lorem vitae metus. Mauris semper egestas massa vel tempus. Donec et ex nec nisl tincidunt pulvinar vel non diam. Nam ac nibh dignissim nisl dapibus venenatis. Vivamus eget libero maximus eros ultrices porta. Morbi at justo mattis, scelerisque dolor euismod, vulputate libero.
\.


--
-- Name: core_analysischart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('core_analysischart_id_seq', 7, true);


--
-- Data for Name: core_expensesbyfunctions; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY core_expensesbyfunctions (id, period_id, committed, committed_deflated, function, authorized) FROM stdin;
1	2	233820497.80	357355114.39	leg	0.00
2	2	252364049.48	385695799.21	jud	0.00
3	2	127352052.36	194636089.08	ess	0.00
4	2	531843856.84	812833451.68	adm	0.00
5	2	559540048.91	855162400.51	seg	0.00
6	2	108528156.73	165866945.92	ass	0.00
7	2	297472487.34	454636422.99	pre	0.00
8	2	1408145448.97	2152112337.17	sau	0.00
9	2	8653977.38	13226141.87	tra	0.00
10	2	1203059895.24	1838673728.48	edu	0.00
11	2	76789881.42	117360355.99	cul	0.00
12	2	111742791.41	170779971.74	dir	0.00
13	2	621305336.38	949560203.85	urb	0.00
14	2	56175349.68	85854528.15	hab	0.00
15	2	169639206.72	259264857.84	san	0.00
16	2	51441530.19	78619685.09	ges	0.00
17	2	49250316.37	75270785.09	cie	0.00
18	2	90466336.67	138262506.47	agr	0.00
19	2	23046762.43	35223081.39	org	0.00
20	2	0.00	0.00	ind	0.00
21	2	22094954.89	33768404.42	cse	0.00
22	2	69201215.74	105762363.01	com	0.00
23	2	2661394.67	4067491.97	ene	0.00
24	2	120042676.03	183464942.67	trn	0.00
25	2	43342383.09	66241507.54	des	0.00
26	2	1546065830.31	2362900331.02	enc	0.00
27	3	251290977.00	368548826.04	leg	0.00
28	3	291218507.06	427107412.20	jud	0.00
29	3	137347290.27	201436530.64	ess	0.00
30	3	488801658.49	716887170.21	adm	0.00
31	3	634424611.26	930460967.92	seg	0.00
32	3	128507206.06	188471470.39	ass	0.00
33	3	333447802.62	489041817.84	pre	0.00
34	3	1595288864.82	2339685432.94	sau	0.00
35	3	9823165.93	14406869.34	tra	0.00
36	3	1190951151.74	1746674926.73	edu	0.00
37	3	98142469.78	143937886.09	cul	0.00
38	3	123860562.71	181656601.94	dir	0.00
39	3	937718282.68	1375278079.46	urb	0.00
40	3	53276865.87	78137013.14	hab	0.00
41	3	311017690.77	456145326.74	san	0.00
42	3	37123835.18	54446626.13	ges	0.00
43	3	42166374.42	61842124.12	cie	0.00
44	3	104300713.49	152969700.58	agr	0.00
45	3	18508900.41	27145556.91	org	0.00
46	3	0.00	0.00	ind	0.00
47	3	24062695.12	35290873.33	cse	0.00
48	3	73566470.51	107894189.70	com	0.00
49	3	1842665.65	2702493.62	ene	0.00
50	3	168725039.31	247455821.55	trn	0.00
51	3	52181927.47	76531152.61	des	0.00
52	3	1579374335.63	2316344837.43	enc	0.00
53	4	281326019.78	389531084.81	leg	0.00
54	4	304347278.00	421406898.13	jud	0.00
55	4	148967887.85	206264685.37	ess	0.00
56	4	505694812.43	700197759.96	adm	0.00
57	4	697917979.80	966354793.60	seg	0.00
58	4	114890253.97	159079936.15	ass	0.00
59	4	366303535.49	507193090.99	pre	0.00
60	4	1713110557.87	2372015978.22	sau	0.00
61	4	10920636.38	15120987.88	tra	0.00
62	4	1482759006.29	2053065424.53	edu	0.00
63	4	117206960.94	162287706.90	cul	0.00
64	4	159065574.26	220246196.02	dir	0.00
65	4	780776962.65	1081083425.89	urb	0.00
66	4	117609481.71	162845047.29	hab	0.00
67	4	339573023.74	470181351.92	san	0.00
68	4	48730744.29	67473814.55	ges	0.00
69	4	47907514.99	66333950.55	cie	0.00
70	4	125814259.22	174205588.65	agr	0.00
71	4	36640651.81	50733568.33	org	0.00
72	4	0.00	0.00	ind	0.00
73	4	28834398.02	39924832.94	cse	0.00
74	4	61856114.28	85647532.06	com	0.00
75	4	622410.00	861804.55	ene	0.00
76	4	165478716.47	229125994.07	trn	0.00
77	4	61109777.18	84614134.93	des	0.00
78	4	2033222088.35	2815250456.94	enc	0.00
79	5	313456059.26	407605092.84	leg	0.00
80	5	374976227.16	487603335.04	jud	0.00
81	5	201825594.78	262445525.83	ess	0.00
82	5	581425396.30	756061162.76	adm	0.00
83	5	808742737.14	1051655084.40	seg	0.00
84	5	113287023.32	147313686.54	ass	0.00
85	5	579986484.62	754190062.45	pre	0.00
86	5	1847750804.85	2402737532.44	sau	0.00
87	5	12829602.75	16683076.51	tra	0.00
88	5	1618033433.65	2104022712.14	edu	0.00
89	5	127685560.38	166036939.33	cul	0.00
90	5	183980057.55	239239938.81	dir	0.00
91	5	542896768.21	705960153.17	urb	0.00
92	5	118501625.91	154094536.71	hab	0.00
93	5	179449704.96	233348858.60	san	0.00
94	5	46886098.41	60968712.94	ges	0.00
95	5	52807530.28	68668694.21	cie	0.00
96	5	105421673.70	137085916.28	agr	0.00
97	5	15063143.28	19587478.80	org	0.00
98	5	0.00	0.00	ind	0.00
99	5	29273778.01	38066391.29	cse	0.00
100	5	53167896.84	69137299.75	com	0.00
101	5	0.00	0.00	ene	0.00
102	5	271986980.10	353680444.20	trn	0.00
103	5	187882915.72	244315051.64	des	0.00
104	5	2249498048.58	2925152772.92	enc	0.00
105	6	398433787.24	489485115.83	leg	0.00
106	6	439794771.01	540298040.28	jud	0.00
107	6	218200757.50	268064673.43	ess	0.00
108	6	629408494.37	773242881.60	adm	0.00
109	6	1104627308.80	1357060177.91	seg	0.00
110	6	130474855.70	160291375.63	ass	0.00
111	6	949580016.13	1166580995.56	pre	0.00
112	6	1955255791.63	2402076927.94	sau	0.00
113	6	13262752.76	16293598.28	tra	0.00
114	6	1883254964.90	2313622248.29	edu	0.00
115	6	213565926.36	262370676.26	cul	0.00
116	6	187646204.59	230527699.03	dir	0.00
117	6	389825410.21	478909525.70	urb	0.00
118	6	131113161.32	161075548.84	hab	0.00
119	6	114306024.94	140427593.37	san	0.00
120	6	53089924.08	65222198.69	ges	0.00
121	6	65762468.16	80790711.97	cie	0.00
122	6	107376847.39	131914938.61	agr	0.00
123	6	75865600.02	93202642.95	org	0.00
124	6	0.00	0.00	ind	0.00
125	6	41831605.76	51391094.45	cse	0.00
126	6	107837104.00	132480374.49	com	0.00
127	6	0.00	0.00	ene	0.00
128	6	201747642.63	247851641.56	trn	0.00
129	6	234382083.81	287943806.77	des	0.00
130	6	2512615481.22	3086806187.74	enc	0.00
131	7	393453560.60	456113133.07	leg	0.00
132	7	501354092.97	581197399.19	jud	0.00
133	7	233098281.89	270220423.23	ess	0.00
134	7	731822514.13	848369142.38	adm	0.00
135	7	1190789857.32	1380429476.41	seg	0.00
136	7	137588450.47	159500143.10	ass	0.00
137	7	1082596618.34	1255005888.60	pre	0.00
138	7	2402368237.99	2784958159.10	sau	0.00
139	7	13518953.19	15671918.40	tra	0.00
140	7	2217016115.87	2570087725.57	edu	0.00
141	7	200971984.12	232977841.65	cul	0.00
142	7	248546862.20	288129272.13	dir	0.00
143	7	877939780.22	1017756360.35	urb	0.00
144	7	85614473.98	99249034.38	hab	0.00
145	7	139029783.23	161171015.77	san	0.00
146	7	78249554.89	90711212.75	ges	0.00
147	7	76085450.28	88202462.97	cie	0.00
148	7	153558821.63	178013880.82	agr	0.00
149	7	68022138.54	78855025.94	org	0.00
150	7	0.00	0.00	ind	0.00
151	7	54845513.56	63579953.34	cse	0.00
152	7	80062922.24	92813368.50	com	0.00
153	7	0.00	0.00	ene	0.00
154	7	306755280.30	355607690.45	trn	0.00
155	7	515173332.68	597217426.33	des	0.00
156	7	2781063343.75	3223962474.89	enc	0.00
157	8	442373624.40	482054538.60	leg	0.00
158	8	510080958.07	555835220.11	jud	0.00
159	8	268247565.49	292309372.17	ess	0.00
160	8	715719018.95	779919015.10	adm	0.00
161	8	1458050065.38	1588837156.55	seg	0.00
162	8	136450346.44	148689942.54	ass	0.00
163	8	1192631178.94	1299610195.94	pre	0.00
164	8	2628231873.23	2863984272.80	sau	0.00
165	8	24177393.96	26346106.20	tra	0.00
166	8	2376870771.32	2590076080.00	edu	0.00
167	8	183391495.97	199841713.20	cul	0.00
168	8	363484346.43	396088892.38	dir	0.00
169	8	1049506600.83	1143647343.14	urb	0.00
170	8	59584913.02	64929679.73	hab	0.00
171	8	200743134.63	218749793.85	san	0.00
172	8	80162766.99	87353367.21	ges	0.00
173	8	97145723.83	105859695.28	cie	0.00
174	8	201119293.13	219159693.77	agr	0.00
175	8	48058134.64	52368949.33	org	0.00
176	8	0.00	0.00	ind	0.00
177	8	56502407.24	61570673.18	cse	0.00
178	8	75780750.43	82578283.76	com	0.00
179	8	0.00	0.00	ene	0.00
180	8	284588432.79	310116015.27	trn	0.00
181	8	238864781.72	260290952.69	des	0.00
182	8	2873528751.13	3131284280.70	enc	0.00
183	9	468096306.60	468096306.60	leg	0.00
184	9	587967590.77	587967590.77	jud	0.00
185	9	280481093.45	280481093.45	ess	0.00
186	9	613896992.61	613896992.61	adm	0.00
187	9	1491252353.33	1491252353.33	seg	0.00
188	9	106587109.30	106587109.30	ass	0.00
189	9	1309309931.15	1309309931.15	pre	0.00
190	9	2637241781.43	2637241781.43	sau	0.00
191	9	14362925.88	14362925.88	tra	0.00
192	9	2445619061.84	2445619061.84	edu	0.00
193	9	113830328.79	113830328.79	cul	0.00
194	9	387889170.01	387889170.01	dir	0.00
195	9	378675520.52	378675520.52	urb	0.00
196	9	28329231.38	28329231.38	hab	0.00
197	9	75859843.94	75859843.94	san	0.00
198	9	40473832.56	40473832.56	ges	0.00
199	9	79161706.53	79161706.53	cie	0.00
200	9	137768129.12	137768129.12	agr	0.00
201	9	13891272.24	13891272.24	org	0.00
202	9	0.00	0.00	ind	0.00
203	9	37448343.79	37448343.79	cse	0.00
204	9	71187695.14	71187695.14	com	0.00
205	9	0.00	0.00	ene	0.00
206	9	104725357.15	104725357.15	trn	0.00
207	9	49676450.34	49676450.34	des	0.00
208	9	3003760351.67	3003760351.67	enc	0.00
\.


--
-- Name: core_expensesbyfunctions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('core_expensesbyfunctions_id_seq', 208, true);


--
-- Data for Name: core_expensesbyfunctionsandorgans; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY core_expensesbyfunctionsandorgans (id, period_id, committed, committed_deflated, function, organ_id, authorized) FROM stdin;
15209	2	9810019.98	14992957.61	dir	79	0.00
15210	2	2119238.84	3238898.41	dir	80	0.00
15211	2	2890000.00	4416876.58	dir	81	0.00
15212	2	1953707.47	2985911.68	dir	82	0.00
15213	2	3487378.38	5329868.47	dir	83	0.00
15214	2	69864873.22	106776651.31	san	80	0.00
15215	2	22899688.38	34998303.56	san	81	0.00
15216	2	11377610.51	17388754.81	san	84	0.00
15217	2	65497034.61	100101148.17	san	85	0.00
15218	2	53560.00	81857.41	ges	86	0.00
15219	2	497372.29	760149.49	ges	87	0.00
15220	2	32715692.77	50000407.33	ges	88	0.00
15221	2	17725507.55	27090442.62	ges	89	0.00
15222	2	384000.00	586879.10	ges	90	0.00
15223	2	54997.58	84054.51	ges	91	0.00
15224	2	10400.00	15894.64	ges	83	0.00
15225	2	10765.36	16453.03	agr	92	0.00
15226	2	41786711.62	63863926.61	agr	93	0.00
15227	2	47090773.44	71970288.70	agr	87	0.00
15228	2	1578086.25	2411838.13	agr	90	0.00
15229	2	13313594.70	20347579.45	org	94	0.00
15230	2	4763167.73	7279696.88	org	95	0.00
15231	2	4970000.00	7595805.05	org	81	0.00
15232	3	12085296.47	17724559.31	dir	79	0.00
15233	3	520397.48	763226.29	dir	80	0.00
15234	3	3593967.59	5270991.23	dir	82	0.00
15235	3	1104419.97	1619766.41	dir	96	0.00
15236	3	1946634.19	2854976.15	dir	83	0.00
15237	3	219595375.92	322063366.40	san	80	0.00
15238	3	5745909.02	8427075.45	san	81	0.00
15239	3	11592169.99	17001329.26	san	84	0.00
15240	3	74084235.84	108653555.62	san	85	0.00
15241	3	7954.05	11665.58	ges	79	0.00
15242	3	120835.00	177219.25	ges	97	0.00
15243	3	661479.88	970140.81	ges	87	0.00
15244	3	17841757.15	26167110.06	ges	88	0.00
15245	3	18332930.54	26887475.66	ges	89	0.00
15246	3	21301.40	31241.10	ges	91	0.00
15247	3	119223.60	174855.93	ges	83	0.00
15248	3	7954.05	11665.58	agr	79	0.00
15249	3	58542.27	85859.37	agr	92	0.00
15250	3	55221027.59	80988363.11	agr	93	0.00
15251	3	47388440.90	69500920.69	agr	87	0.00
15252	3	232400.00	340842.91	agr	80	0.00
15253	3	1384973.11	2031231.76	agr	90	0.00
15254	3	10073596.31	14774155.99	org	94	0.00
15255	3	8435304.10	12371400.92	org	95	0.00
15256	4	12392773.17	17159345.52	dir	79	0.00
15257	4	1494793.27	2069728.37	dir	80	0.00
15258	4	3111493.57	4308252.28	dir	82	0.00
15259	4	3347403.41	4634898.98	dir	96	0.00
15260	4	290724381.25	402544292.55	san	80	0.00
15261	4	695663.76	963233.54	san	81	0.00
15262	4	10453791.52	14474582.74	san	84	0.00
15263	4	37699187.21	52199243.08	san	85	0.00
15264	4	6592.50	9128.14	ges	98	0.00
15265	4	3000.00	4153.88	ges	79	0.00
15266	4	286894.83	397241.80	ges	97	0.00
15267	4	1721642.02	2383828.86	ges	87	0.00
15268	4	27143598.39	37583709.23	ges	88	0.00
15269	4	18872332.07	26131105.79	ges	89	0.00
15270	4	657592.38	910518.95	ges	90	0.00
15271	4	39092.10	54127.91	ges	91	0.00
15272	4	57998128.15	80305667.40	agr	93	0.00
15273	4	67366907.07	93277914.40	agr	87	0.00
15274	4	449224.00	622006.85	agr	90	0.00
15275	4	8111647.45	11231591.14	org	99	0.00
15276	4	12272746.11	16993153.03	org	94	0.00
15277	4	10256258.25	14201073.21	org	95	0.00
15278	4	6000000.00	8307750.95	org	81	0.00
15279	5	12956423.66	16847989.10	dir	79	0.00
15280	5	1843078.25	2396661.54	dir	100	0.00
15281	5	308772.81	401515.19	dir	80	0.00
15282	5	3353373.13	4360585.56	dir	82	0.00
15283	5	3342595.76	4346571.12	dir	96	0.00
15284	5	141682921.49	184238519.76	san	80	0.00
15285	5	11828014.76	15380653.56	san	84	0.00
15286	5	25938768.71	33729685.28	san	85	0.00
15287	5	64304.82	83619.29	ges	98	0.00
15288	5	352610.56	458519.96	ges	92	0.00
15289	5	1604435.10	2086340.01	ges	87	0.00
15290	5	19851554.62	25814127.77	ges	88	0.00
15291	5	20972645.12	27271946.76	ges	89	0.00
15292	5	1780608.15	2315428.04	ges	90	0.00
15293	5	327833.24	426300.57	ges	101	0.00
15294	5	107996.00	140433.46	ges	91	0.00
15295	5	50000.00	65017.90	ges	96	0.00
15296	5	1774110.80	2306979.16	ges	102	0.00
15297	5	7932.25	10314.76	agr	79	0.00
15298	5	53402484.01	69442347.05	agr	93	0.00
15299	5	50032067.28	65059598.71	agr	87	0.00
15300	5	1979190.16	2573655.75	agr	90	0.00
15301	5	7820480.61	10169424.49	org	94	0.00
15302	5	5411662.67	7037098.82	org	95	0.00
15303	5	1831000.00	2380955.49	org	81	0.00
15304	6	12195213.16	14982101.21	dir	79	0.00
15305	6	3516934.20	4320634.94	dir	100	0.00
15306	6	3425562.27	4208382.42	dir	82	0.00
15307	6	3961140.00	4866352.04	dir	96	0.00
15308	6	64653832.75	79428727.75	san	80	0.00
15309	6	418669.90	514345.65	san	81	0.00
15310	6	11680587.40	14349871.57	san	84	0.00
15311	6	37552934.89	46134648.40	san	85	0.00
15312	6	1196.00	1469.31	ges	98	0.00
15313	6	30000.00	36855.69	ges	103	0.00
15314	6	410000.00	503694.48	ges	104	0.00
15315	6	233826.16	287260.84	ges	87	0.00
15316	6	91140.00	111967.60	ges	95	0.00
15317	6	27126543.54	33325585.66	ges	88	0.00
15318	6	22363852.99	27474510.25	ges	89	0.00
15319	6	2343.65	2879.23	ges	90	0.00
15320	6	33203.26	40790.97	ges	91	0.00
15321	6	2797818.48	3437184.66	ges	102	0.00
15322	6	53155411.39	65302651.37	agr	93	0.00
15323	6	51167212.08	62860102.57	agr	87	0.00
15324	6	3054223.92	3752184.67	agr	90	0.00
15325	6	14166888.78	17404350.28	org	94	0.00
15326	6	6564454.02	8064583.47	org	95	0.00
15327	6	55134257.22	67733709.20	org	81	0.00
15328	7	16459218.47	19080436.56	dir	79	0.00
15329	7	5537341.05	6419192.07	dir	100	0.00
15330	7	55451.48	64282.42	dir	91	0.00
15331	7	3379205.99	3917362.52	dir	82	0.00
15332	7	4316822.33	5004299.25	dir	96	0.00
15333	7	83910558.57	97273761.38	san	80	0.00
15334	7	513441.50	595209.79	san	81	0.00
15335	7	13303445.22	15422089.64	san	84	0.00
15336	7	41302337.94	47879954.96	san	85	0.00
15337	7	811050.42	940214.51	ges	95	0.00
15338	7	47484069.58	55046160.25	ges	88	0.00
15339	7	26840833.20	31115378.66	ges	89	0.00
15340	7	152396.18	176666.08	ges	90	0.00
15341	7	2961205.51	3432793.24	ges	102	0.00
15342	7	70110355.29	81275802.32	agr	93	0.00
15343	7	70307784.99	81504673.75	agr	87	0.00
15344	7	6907967.55	8008098.13	agr	105	0.00
15345	7	2688460.62	3116612.27	agr	90	0.00
15346	7	3544253.18	4108694.35	agr	106	0.00
15347	7	59550317.35	69034022.16	org	94	0.00
15348	7	8466278.45	9814578.33	org	95	0.00
15349	7	5542.74	6425.45	org	107	0.00
15350	8	19213512.04	20936964.07	dir	79	0.00
15351	8	7854374.06	8558911.41	dir	100	0.00
15352	8	100246.57	109238.69	dir	91	0.00
15353	8	4152824.81	4525333.20	dir	82	0.00
15354	8	8475239.23	9235468.19	dir	96	0.00
15355	8	139661746.25	152189404.92	san	80	0.00
15356	8	15257394.39	16625982.67	san	81	0.00
15357	8	15365134.92	16743387.53	san	84	0.00
15358	8	30458859.07	33191018.73	san	85	0.00
15359	8	50886188.65	55450679.78	ges	88	0.00
15360	8	26111472.39	28453671.47	ges	89	0.00
15361	8	262192.02	285710.64	ges	101	0.00
15362	8	2894963.93	3154642.20	ges	102	0.00
15363	8	7950.00	8663.12	ges	108	0.00
15364	8	99521462.10	108448537.27	agr	93	0.00
15365	8	72947755.91	79491169.63	agr	87	0.00
15366	8	8642672.41	9417920.13	agr	105	0.00
15367	8	5938636.33	6471332.01	agr	80	0.00
15368	8	14068766.38	15330734.73	agr	90	0.00
15369	8	40212465.26	43819523.40	org	94	0.00
15370	8	7272304.81	7924630.55	org	95	0.00
15371	8	573364.57	624795.37	org	107	0.00
15372	9	15677923.13	15677923.13	dir	79	0.00
15373	9	2644409.72	2644409.72	dir	100	0.00
15374	9	635855.22	635855.22	dir	80	0.00
15375	9	769459.81	769459.81	dir	82	0.00
15376	9	4886101.78	4886101.78	dir	96	0.00
15377	9	39263338.43	39263338.43	san	80	0.00
15378	9	12827378.21	12827378.21	san	81	0.00
15379	9	17373064.65	17373064.65	san	84	0.00
15380	9	3419172.32	3419172.32	san	85	0.00
15381	9	2976890.33	2976890.33	san	109	0.00
15382	9	14238184.14	14238184.14	ges	88	0.00
15383	9	24738565.50	24738565.50	ges	89	0.00
15384	9	774835.64	774835.64	ges	102	0.00
15385	9	220800.99	220800.99	ges	110	0.00
15386	9	58008146.42	58008146.42	agr	93	0.00
15387	9	63213490.33	63213490.33	agr	87	0.00
15388	9	9086360.30	9086360.30	agr	105	0.00
15389	9	11332176.87	11332176.87	org	94	0.00
15390	9	1381556.29	1381556.29	org	95	0.00
15391	9	1177539.08	1177539.08	org	107	0.00
\.


--
-- Name: core_expensesbyfunctionsandorgans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('core_expensesbyfunctionsandorgans_id_seq', 15391, true);


--
-- Data for Name: core_expensesbysourcesofresources; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY core_expensesbysourcesofresources (id, period_id, committed, committed_deflated, source_classification, authorized) FROM stdin;
1	2	416736.62	0.00	con	5344227.37
2	2	416736.62	0.00	cre	5344227.37
3	2	416736.62	0.00	doa	5344227.37
4	2	416736.62	0.00	out	5344227.37
5	2	416736.62	0.00	tes	5344227.37
6	3	3609353.19	0.00	con	6603233.85
7	3	3609353.19	0.00	cre	6603233.85
8	3	3609353.19	0.00	doa	6603233.85
9	3	3609353.19	0.00	out	6603233.85
10	3	3609353.19	0.00	tes	6603233.85
11	4	2214506.69	0.00	con	4209547.15
12	4	2214506.69	0.00	cre	4209547.15
13	4	2214506.69	0.00	doa	4209547.15
14	4	2214506.69	0.00	out	4209547.15
15	4	2214506.69	0.00	tes	4209547.15
16	5	2387858.38	0.00	con	5815881.36
17	5	2387858.38	0.00	cre	5815881.36
18	5	2387858.38	0.00	doa	5815881.36
19	5	2387858.38	0.00	out	5815881.36
20	5	2387858.38	0.00	tes	5815881.36
21	6	457552.49	0.00	con	21088830.98
22	6	457552.49	0.00	cre	21088830.98
23	6	457552.49	0.00	doa	21088830.98
24	6	457552.49	0.00	out	21088830.98
25	6	457552.49	0.00	tes	21088830.98
26	7	22999048.37	0.00	con	44478388.31
27	7	22999048.37	0.00	cre	44478388.31
28	7	22999048.37	0.00	doa	44478388.31
29	7	22999048.37	0.00	out	44478388.31
30	7	22999048.37	0.00	tes	44478388.31
\.


--
-- Name: core_expensesbysourcesofresources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('core_expensesbysourcesofresources_id_seq', 30, true);


--
-- Data for Name: core_governmentprogram; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY core_governmentprogram (id, committed, committed_deflated, authorized, program, period_id) FROM stdin;
1	988.27	1214.11	0.00	ain	6
2	9392.40	11538.79	0.00	rfu	6
3	103147.90	126719.58	0.00	pdr	6
4	18673.54	22940.87	0.00	mad	6
5	64181.70	78848.71	0.00	drs	6
6	1007.65	1168.12	0.00	ain	7
7	55268.64	64070.47	0.00	rfu	7
8	91594.56	106181.48	0.00	pdr	7
9	40433.06	46872.23	0.00	mad	7
10	97235.77	112721.09	0.00	drs	7
11	4823.66	5256.34	0.00	ain	8
12	34656.74	37765.46	0.00	rfu	8
13	100715.89	109750.10	0.00	pdr	8
14	43168.06	47040.24	0.00	mad	8
15	140829.77	153462.20	0.00	drs	8
16	2325.22	2325.22	0.00	ain	9
17	3241.90	3241.90	0.00	rfu	9
18	80286.21	80286.21	0.00	pdr	9
19	7891.90	7891.90	0.00	mad	9
20	83830.09	83830.09	0.00	drs	9
\.


--
-- Name: core_governmentprogram_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('core_governmentprogram_id_seq', 20, true);


--
-- Data for Name: core_organ; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY core_organ (id, initials, name, description) FROM stdin;
79	OGE	OGE	
82	SEARP	SEARP	
86	FUAM	FUAM	
91	CETAM	CETAM	
92	FUNTEC	FUNTEC	
97	AGECOM	AGECOM	
98	PGJ	PGJ	
100	FPS	FPS	
101	FEMA	FEMA	
103	CASA CIVIL	CASA CIVIL	
104	AMAZONASTUR	AMAZONASTUR	
106	FAPEAM	FAPEAM	
108	FERH	FERH	
109	UGPE	UGPE	
110	SCADCIVIL	SCADCIVIL	
99	FERMM	Fundo Especial da Região Metropolitana de Manaus	# Dar suporte financeiro ao planejamento integrado e às ações conjuntas dele decorrentes, no que se refere às funções públicas de interesse comum entre o Estado e os Municípios integrantes da Região Metropolitana de Manaus.
93	SEPROR	Secretaria de Estado de Produção Rural	# Formular, coordenar e implementar a política estadual de desenvolvimento integrado da agricultura, da pecuária, florestal, da pesca e da aquicultura; \n# Implementar ações de fomento, assistência técnica e extensão rural aos produtores dos setores da agricultura, pecuária, florestal pesca e aquicultura;  \n# Incentivar à organização dos produtores mediante associativismo e cooperativismo;  \n# Coordenar a produção agropecuária, florestal e pesqueira e de apoio às ações de escoamento, armazenamento e beneficiamento da produção, de reforma agrária, de defesa sanitária animal e vegetal e de capacitação profissional dos produtores agropecuários, florestais, pescadores e aquicultores. 
87	IDAM	Instituto de Desenvolvimento Agropecuário e Florestal Sustentável do Estado do Amazonas	# Supervisionar, coordenar e executar as atividades de assistência técnica e extensão agropecuária e florestal, no âmbito das políticas e estratégias do Governo Estadual para os setores agropecuário, florestal, pesqueiro e agroindustrial. 
105	ADAF	Agência de Defesa Agropecuária e Florestal do Estado do Amazonas	# Elaborar, coordenar e executar a política de defesa agropecuária no Estado do Amazonas, garantindo a preservação e a sanidade do patrimônio animal e vegetal do Estado, bem como promover a idoneidade dos insumos e dos serviços utilizados na agropecuária, a identidade e a segurança higiênico-sanitária e tecnológica dos produtos agropecuários finais destinados aos consumidores. 
94	SPF	Secretaria de Estado de Política Fundiária	# Formular, coordenar, controlar e avaliar as políticas fundiárias e de reforma agrária e gerir o patrimônio fundiário estadual. 
95	ITEAM	Instituto de Terras do Amazonas	# Coordenar e controlar a execução de políticas estaduais relativas às questões fundiárias e de reforma agrária, em todos os seus aspectos. 
107	FERF	Fundo Estadual de Regularização Fundiária	# Centralizar e gerenciar recursos orçamentários para os programas destinados a implementação da Política Estadual de Regularização Fundiária. 
80	SEINFRA	Secretaria de Estado de Infraestrutura	# Formular políticas estaduais de infraestrutura e planejamento, nas áreas de transportes, energia, habitação, telecomunicação, saneamento básico, sistema viário e urbanização, viabilizando a execução de programas e projetos com vistas ao desenvolvimento sustentável do Estado do Amazonas;                                                                                                                        \n# Abrir e conservar a malha rodoviária estadual e a malha de ramais vicinais, essenciais à circulação da população e ao escoamento de produção;                                                                        \n# Coordenar e executar as atividades de infraestrutura nas rodovias, portos, aeroportos e hidrovias; supervisionar a manutenção e a fiscalização da infraestrutura estadual para o transporte aquaviário no interior do Estado do Amazonas, abrangendo a navegação, os portos e as hidrovias. 
81	SUHAB	Superintendência Estadual de Habitação	# Supervisionar, coordenar, executar e controlar as atividades relativas à Política Estadual de Habitação, formulada pela Secretaria de Estado de Infraestrutura;  \n# Prestar auxílio técnico nos procedimentos de desapropriações de interesse do Estado, compreendendo a identificação e avaliação dos imóveis expropriandos, bem como a elaboração dos documentos necessários à instrução dos processos de desapropriação; \n# Promover as desapropriações de interesse do Estado do Amazonas, conforme o disposto no ato específico de declaração de utilidade pública e interesse social. 
84	COSAMA	Companhia de Saneamento do Amazonas S/A	# Executar, operacionalizar, manter e explorar os sistemas de abastecimento de água e esgotos sanitários nos municípios do Estado do Amazonas, mediante delegação, nas respectivas sedes municipais; \n# Conservar, proteger e fiscalizar as áreas e/ou bacias hidrográficas utilizadas ou reservadas para os fins de abastecimento de água. 
85	FEH	Fundo Estadual de Habitação	# Promover, incentivar, apoiar e custear ações na área de habitação, desapropriar, indenizar, efetuar permutas de imóveis e financiar moradias de interesse social para a população residente na área de atuação do Programa Social e Ambiental dos Igarapés de Manaus - PROSAMIM e demais áreas assim consideradas, para fins de execução das ações relativas à Política Estadual de Habitação. 
88	SDS/SEMA	Secretaria de Estado do Meio Ambiente e Desenvolvimento Sustentável	# Substituição pela SEMA em 2015;\n# Coordenar e implementar a política estadual de meio ambiente, dos recursos hídricos e da fauna e flora, da gestão da política estadual de florestas e de ordenamento pesqueiro, etno-desenvolvimento sustentável dos povos indígenas, visando a valorização econômica e a sustentabilidade dos produtos florestais madeireiros e não madeireiros; \n# Coordenar e articular a política estadual de desenvolvimento sustentável, em ação conjunta com a colaboração da Secretaria de Estado de Produção Agropecuária, Pesca e Desenvolvimento Rural Integrado na atividades inerentes ao setor agrícola, pecuário e pesqueiro; \n# Ações de fortalecimento das cadeias produtivasmdo setor florestal nos pólos de desenvolvimento sustentável e implementação das ações de assistência técnica e organização dos produtores florestais madeireiros e não-madeireiros.\n
89	IPAAM	Instituto de Proteção Ambiental do Estado do Amazonas	# Implementar e executar a política nacional e estadual de meio ambiente;  \n# Gestão ambiental. 
111	SEMA	Secretaria de Estado do Meio Ambiente	# Formular, coordenar e implementar a política estadual de meio ambiente; #Coordenar a formulação e avaliar as políticas estaduais de ordenamento pesqueiro, etno-desenvolvimento sustentável dos povos indígenas e da política estadual de desenvolvimento sustentável; \n# Formular e coordenar as políticas estaduais de promoção de negócios sustentáveis, de serviços ambientais, mudanças climáticas e das cadeias produtivas, relacionadas a recursos florestais visando ao desenvolvimento sustentável do Amazonas. 
90	ADS	Agência de Desenvolvimento Sustentável do Amazonas	# Implementar e executar a política estadual de desenvolvimento sustentável dos recursos de natureza ambiental, bem como os originários da floresta, da mineração, da pesca e da agropecuária;\n# Apoiar a comercialização de produtos ambientais, incluindo os originários da floresta, da mineração, da pesca e da agropecuária; \n# Dinamizar as cadeias produtivas florestais, minerais, pesqueiras e agropecuárias sustentáveis do Estado do Amazonas. 
96	SEIND	Secretaria de Estado para os Povos Indígenas	# Criada em 2009; \n# Formular, executar e implementar a política de etnodesenvolvimento do Estado, em parceria com outras instituições dos governos federal, estadual e municipal, com as comunidades, organizações indígenas e entidades não-governamentais, com atividades voltadas ao desenvolvimento sustentável e à preservação de valores culturais e históricos definidos e aprovados pelo Conselho Estadual dos Povos Indígenas. 
83	FEPI	Fundação Estadual dos Povos Indígenas	# Coordenar as ações do Governo Estadual em atenção às comunidades indígenas; \n# Implementar política de etno- desenvolvimento que fortaleça as organizações tradicionais e as organizações das comunidades indígenas e possibilite a apropriação de novas formas de saber; \n# Estabelecer parcerias com organismos governamentais, entidades não-governamentais, organizações indígenas e empresas privadas, com vistas a viabilizar a execução das ações promotoras do etno-desenvolvimento; \n# Valorizar a diversidade cultural constitutiva da sociedade regional, respeitando os processos próprios das comunidades, em atenção ao reconhecimento da cidadania indígena.
102	SEMGRH	Secretaria de Estado de Mineração, Geodiversidade e Recursos Hídricos	# Criada em 2011; \n# Formular, coordenar, implementar políticas públicas destinadas aos setores mineral e de óleo e gás, e da política estadual de recursos hídricos, visando o fomento e atração de investimentos da mineração, da indústria de óleo e gás e da indústria de transformação mineral, em articulação com as políticas estaduais de infraestrutura, de produção agropecuária, pesca e desenvolvimento rural, de desenvolvimento sustentável e de planejamento estratégico à sustentabilidade da economia industrial do Amazonas; \n# Promover a gestão e o uso sustentável dos recursos hídricos superficiais e subterrâneos. 
\.


--
-- Name: core_organ_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('core_organ_id_seq', 111, true);


--
-- Data for Name: core_period; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY core_period (id, year) FROM stdin;
1	1900
2	2008
3	2009
4	2010
5	2011
6	2012
7	2013
8	2014
9	2015
\.


--
-- Name: core_period_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('core_period_id_seq', 9, true);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2017-01-16 14:35:28.165423+00	2	daniel	1	[{"added": {}}]	4	1
2	2017-01-16 14:36:16.235538+00	2	daniel	2	[{"changed": {"fields": ["first_name", "last_name", "email", "is_staff", "is_superuser"]}}]	4	1
3	2017-01-17 16:33:57.329616+00	1	Análise de Custos - 2017-01-17 16:33:57.301746+00:00	1	[{"added": {}}, {"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/gr\\u00e1ficos-no-excel-tipo-de-gr\\u00e1fico-1024x644.png - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/gr\\u00e1ficos-no-excel-tipo-de-gr\\u00e1fico-1024x644.png"}}, {"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/grc3a1fico-ii.gif - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/grc3a1fico-ii.gif"}}, {"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/screen-shot-2010-03-27-at-10-21-12.png - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/screen-shot-2010-03-27-at-10-21-12.png"}}]	7	2
4	2017-01-17 16:34:56.881295+00	2	Custos na saúde - 2017-01-17 16:34:56.861710+00:00	1	[{"added": {}}, {"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/images.jpg - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/images.jpg"}}, {"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/depositphotos_3989956-stock-illustration-pie-chart.jpg - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/depositphotos_3989956-stock-illustration-pie-chart.jpg"}}, {"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/grafico-barra.jpg - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/grafico-barra.jpg"}}]	7	2
5	2017-01-17 16:35:37.734872+00	3	Distribuição de Despesas - 2017-01-17 16:35:37.726539+00:00	1	[{"added": {}}, {"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/gr\\u00e1fico_001.png - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/gr\\u00e1fico_001.png"}}, {"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/allgraphscharts.png - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/allgraphscharts.png"}}, {"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/Untitled-614.jpg - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/Untitled-614.jpg"}}, {"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/graficl.JPG - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/graficl.JPG"}}]	7	2
6	2017-01-17 16:37:44.660226+00	3	fernanda	1	[{"added": {}}]	4	2
7	2017-01-17 16:39:03.294408+00	3	fernanda	2	[{"changed": {"fields": ["first_name", "last_name", "email", "is_superuser"]}}]	4	2
8	2017-01-17 16:39:15.85717+00	2	daniel	2	[]	4	2
9	2017-01-17 16:39:22.255962+00	3	fernanda	2	[{"changed": {"fields": ["is_staff"]}}]	4	2
10	2017-02-15 03:37:24.665365+00	1	TCE	2	[{"changed": {"fields": ["description"]}}]	11	3
11	2017-04-04 04:00:59.139854+00	2	Custos na Saúde - 2017-01-17 16:34:56.861710+00:00	2	[{"changed": {"fields": ["title"]}}]	7	3
12	2017-04-04 04:01:30.694359+00	1	Orçamento do Amazonas - 2017-01-17 16:33:57.301746+00:00	2	[{"changed": {"fields": ["title"]}}]	7	3
13	2017-04-04 04:01:51.677923+00	2	As Funções Executadas pelo Estado - 2017-01-17 16:34:56.861710+00:00	2	[{"changed": {"fields": ["title"]}}]	7	3
14	2017-04-04 04:02:09.14164+00	3	Gestão Ambiental no Amazonas - 2017-01-17 16:35:37.726539+00:00	2	[{"changed": {"fields": ["title"]}}]	7	3
15	2017-04-04 04:02:43.189475+00	4	A Gestão Ambiental no Cenário Amazônico - 2017-04-04 04:02:43.184526+00:00	1	[{"added": {}}]	7	3
16	2017-04-04 04:03:13.580074+00	5	Outras Funções Orçamentárias - 2017-04-04 04:03:13.577698+00:00	1	[{"added": {}}]	7	3
17	2017-04-04 04:03:41.357705+00	5	Outras Funções Orçamentárias - 2017-04-04 04:03:13.577698+00:00	2	[{"changed": {"fields": ["description"]}}]	7	3
18	2017-04-04 04:03:56.741837+00	5	Outras Funções Orçamentárias - 2017-04-04 04:03:13.577698+00:00	2	[{"changed": {"fields": ["description"]}}]	7	3
19	2017-04-04 04:04:32.792031+00	5	Outras Funções Orçamentárias - 2017-04-04 04:03:13.577698+00:00	2	[{"changed": {"fields": ["description"]}}]	7	3
20	2017-04-04 04:04:55.12782+00	5	Outras Funções Orçamentárias - 2017-04-04 04:03:13.577698+00:00	2	[{"changed": {"fields": ["description"]}}]	7	3
21	2017-04-04 04:05:15.676324+00	5	Outras Funções Orçamentárias - 2017-04-04 04:03:13.577698+00:00	2	[{"changed": {"fields": ["description"]}}]	7	3
22	2017-04-04 04:05:37.232349+00	5	Outras Funções Orçamentárias - 2017-04-04 04:03:13.577698+00:00	3		7	3
23	2017-04-04 04:06:31.846272+00	6	Outras Funções Orçamentárias - 2017-04-04 04:06:31.839166+00:00	1	[{"added": {}}, {"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/landscape.jpg - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/landscape.jpg"}}]	7	3
24	2017-04-04 04:07:05.749533+00	4	A Gestão Ambiental no Cenário Amazônico - 2017-04-04 04:02:43.184526+00:00	2	[{"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/slide4.jpg - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/slide4.jpg"}}]	7	3
25	2017-04-04 04:07:12.218602+00	4	A Gestão Ambiental no Cenário Amazônico - 2017-04-04 04:02:43.184526+00:00	2	[]	7	3
26	2017-04-04 04:07:18.246853+00	2	As Funções Executadas pelo Estado - 2017-01-17 16:34:56.861710+00:00	2	[]	7	3
27	2017-04-04 04:07:22.997433+00	3	Gestão Ambiental no Amazonas - 2017-01-17 16:35:37.726539+00:00	2	[]	7	3
28	2017-04-04 04:07:28.814326+00	1	Orçamento do Amazonas - 2017-01-17 16:33:57.301746+00:00	2	[]	7	3
29	2017-04-04 04:07:33.206882+00	6	Outras Funções Orçamentárias - 2017-04-04 04:06:31.839166+00:00	2	[]	7	3
30	2017-04-04 04:08:54.332356+00	6	Outras Funções Orçamentárias - 2017-04-04 04:06:31.839166+00:00	2	[{"changed": {"fields": ["description"]}}]	7	3
31	2017-04-04 04:10:18.472577+00	6	Outras Funções Orçamentárias - 2017-04-04 04:06:31.839166+00:00	2	[{"changed": {"fields": ["description"]}}]	7	3
32	2017-04-04 04:11:28.716103+00	6	Outras Funções Orçamentárias - 2017-04-04 04:06:31.839166+00:00	2	[{"changed": {"fields": ["description"]}}]	7	3
33	2017-04-04 04:16:31.547783+00	6	Outras Funções Orçamentárias - 2017-04-04 04:06:31.839166+00:00	2	[{"changed": {"fields": ["description"]}}]	7	3
34	2017-04-04 19:29:35.684437+00	7	teste - 2017-04-04 19:29:35.678009+00:00	1	[{"added": {}}]	7	3
35	2017-04-04 19:32:54.151131+00	7	teste - 2017-04-04 19:29:35.678009+00:00	2	[{"changed": {"fields": ["description"]}}]	7	3
36	2017-04-04 19:33:32.497153+00	7	teste - 2017-04-04 19:29:35.678009+00:00	2	[{"added": {"name": "Imagem da An\\u00e1lise", "object": "analysis/hi-tech-wallpaper-26.jpg - /root/workspace/homolog_idesam_transp/idesam_public_transparency/media/analysis/hi-tech-wallpaper-26.jpg"}}]	7	3
37	2017-04-04 19:34:24.170337+00	7	teste - 2017-04-04 19:29:35.678009+00:00	3		7	3
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 37, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	group
3	auth	permission
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	core	analysischart
8	core	analiseimage
9	core	period
10	core	expensesbysourcesofresources
11	core	organ
12	core	expensesbyfunctionsandorgans
13	core	expensesbyfunctions
14	corsheaders	corsmodel
15	core	governmentprogram
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('django_content_type_id_seq', 15, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2017-01-12 20:53:30.774505+00
2	auth	0001_initial	2017-01-12 20:53:30.937615+00
3	admin	0001_initial	2017-01-12 20:53:30.982197+00
4	admin	0002_logentry_remove_auto_add	2017-01-12 20:53:31.006086+00
5	contenttypes	0002_remove_content_type_name	2017-01-12 20:53:31.058145+00
6	auth	0002_alter_permission_name_max_length	2017-01-12 20:53:31.089979+00
7	auth	0003_alter_user_email_max_length	2017-01-12 20:53:31.128924+00
8	auth	0004_alter_user_username_opts	2017-01-12 20:53:31.154493+00
9	auth	0005_alter_user_last_login_null	2017-01-12 20:53:31.178557+00
10	auth	0006_require_contenttypes_0002	2017-01-12 20:53:31.181675+00
11	auth	0007_alter_validators_add_error_messages	2017-01-12 20:53:31.201861+00
12	auth	0008_alter_user_username_max_length	2017-01-12 20:53:31.228485+00
13	core	0001_initial	2017-01-12 20:53:31.307264+00
14	core	0002_auto_20161212_1946	2017-01-12 20:53:31.35164+00
15	core	0003_auto_20161212_1952	2017-01-12 20:53:31.381879+00
16	core	0004_auto_20161212_1959	2017-01-12 20:53:31.411169+00
17	core	0005_auto_20161213_1443	2017-01-12 20:53:31.514998+00
18	core	0006_auto_20161213_1520	2017-01-12 20:53:31.526117+00
19	core	0007_auto_20161219_1947	2017-01-12 20:53:31.544382+00
20	core	0008_auto_20161230_1443	2017-01-12 20:53:31.562399+00
21	core	0009_auto_20161230_1447	2017-01-12 20:53:31.57273+00
22	core	0010_auto_20161230_2012	2017-01-12 20:53:31.599075+00
23	core	0011_auto_20161230_2217	2017-01-12 20:53:31.606398+00
24	core	0012_auto_20170104_1441	2017-01-12 20:53:31.624304+00
25	core	0013_auto_20170104_1813	2017-01-12 20:53:31.682733+00
26	core	0014_auto_20170104_1910	2017-01-12 20:53:31.844797+00
27	sessions	0001_initial	2017-01-12 20:53:31.8587+00
28	core	0015_auto_20170118_2040	2017-01-18 21:09:45.48118+00
29	core	0016_auto_20170404_1816	2017-04-04 19:19:56.523344+00
30	core	0017_auto_20170406_0240	2017-04-06 04:49:58.06374+00
31	core	0018_governmentprogram	2017-04-25 20:49:32.831675+00
32	core	0019_auto_20170425_2245	2017-04-26 19:31:28.252316+00
33	core	0020_auto_20170426_1950	2017-04-26 19:51:52.56565+00
34	core	0021_auto_20170427_1413	2017-04-27 14:18:25.799759+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sky
--

SELECT pg_catalog.setval('django_migrations_id_seq', 34, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: sky
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
y9s78gs4y5f2v87jxliswlz4bsu83gfn	MTNiZjU1YjNjY2NhOWY2NjYyMWJkZjY0Y2JiOGNmNzQwOWNmNzQ0YTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJmOWNhMGEzZTcwMmVlNWE1NGJiN2VlOTgxYmIwMDc5Nzg4M2I2NDQwIn0=	2017-01-26 21:01:06.106403+00
7ocqwdibhlluy16o916nx7rr9eug5t22	NTRlZWMyZTI2MWM2ZTY3OGI1NTMxMzRjYmZiMjVlZjQxMmU0MmNlMjp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1NTUzMjY0MTY1OWQ1Mjg1ODU3YjJkODVhNWJlOGMwMWJkOTBhYWQwIn0=	2017-01-30 14:50:46.049286+00
iyse93o857i18uyelwpt5fhb4nozdqif	NjJhNWU5MGM5YWQ0MGZiMjU2MWYwYmE0ZDJmZjAwMzgxNTk0Yzg1ODp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzN2FmZTAyNDc0ZjIwMjhiODkyYzY0NGM2NmMyYmNkYzExZmZjNjU5In0=	2017-01-31 19:40:16.03312+00
pjc48rtuxwjzwobeut3lmhnagabocx2j	NjJhNWU5MGM5YWQ0MGZiMjU2MWYwYmE0ZDJmZjAwMzgxNTk0Yzg1ODp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzN2FmZTAyNDc0ZjIwMjhiODkyYzY0NGM2NmMyYmNkYzExZmZjNjU5In0=	2017-01-31 21:59:46.433284+00
fgxjwchm3tgiehfibo5mw5pkkksvc11d	NjJhNWU5MGM5YWQ0MGZiMjU2MWYwYmE0ZDJmZjAwMzgxNTk0Yzg1ODp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzN2FmZTAyNDc0ZjIwMjhiODkyYzY0NGM2NmMyYmNkYzExZmZjNjU5In0=	2017-02-01 15:29:14.971145+00
tfl0dubizack55o9d3cs9vo7862eue5u	NjJhNWU5MGM5YWQ0MGZiMjU2MWYwYmE0ZDJmZjAwMzgxNTk0Yzg1ODp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzN2FmZTAyNDc0ZjIwMjhiODkyYzY0NGM2NmMyYmNkYzExZmZjNjU5In0=	2017-03-01 03:36:55.48335+00
1rfsxhdew7f70k1a1f5hfgnxb75l3m6d	NjJhNWU5MGM5YWQ0MGZiMjU2MWYwYmE0ZDJmZjAwMzgxNTk0Yzg1ODp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzN2FmZTAyNDc0ZjIwMjhiODkyYzY0NGM2NmMyYmNkYzExZmZjNjU5In0=	2017-03-21 18:29:32.751873+00
g3w8ak2ao45urqozhncgrb0ykhkk972u	NTRlZWMyZTI2MWM2ZTY3OGI1NTMxMzRjYmZiMjVlZjQxMmU0MmNlMjp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1NTUzMjY0MTY1OWQ1Mjg1ODU3YjJkODVhNWJlOGMwMWJkOTBhYWQwIn0=	2017-04-11 19:33:00.519616+00
f1c6rxwng70c72g85ym3xmy0047ahzkn	NTRlZWMyZTI2MWM2ZTY3OGI1NTMxMzRjYmZiMjVlZjQxMmU0MmNlMjp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1NTUzMjY0MTY1OWQ1Mjg1ODU3YjJkODVhNWJlOGMwMWJkOTBhYWQwIn0=	2017-04-14 18:13:20.886268+00
svol5rganl2r4q597ukvrekw3e2syiqh	NjJhNWU5MGM5YWQ0MGZiMjU2MWYwYmE0ZDJmZjAwMzgxNTk0Yzg1ODp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzN2FmZTAyNDc0ZjIwMjhiODkyYzY0NGM2NmMyYmNkYzExZmZjNjU5In0=	2017-04-18 04:00:40.991809+00
vbie67nnxyhzt1h98zkv9p9c01purqq2	NjJhNWU5MGM5YWQ0MGZiMjU2MWYwYmE0ZDJmZjAwMzgxNTk0Yzg1ODp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzN2FmZTAyNDc0ZjIwMjhiODkyYzY0NGM2NmMyYmNkYzExZmZjNjU5In0=	2017-04-18 19:35:59.244159+00
8ltuyvm1p8qnu1k4ehbgl4hvf40u9gj5	NjJhNWU5MGM5YWQ0MGZiMjU2MWYwYmE0ZDJmZjAwMzgxNTk0Yzg1ODp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzN2FmZTAyNDc0ZjIwMjhiODkyYzY0NGM2NmMyYmNkYzExZmZjNjU5In0=	2017-04-20 15:03:22.410181+00
nzvkhymlngwt0ctj1hubfx6r9yyllo0j	NjJhNWU5MGM5YWQ0MGZiMjU2MWYwYmE0ZDJmZjAwMzgxNTk0Yzg1ODp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzN2FmZTAyNDc0ZjIwMjhiODkyYzY0NGM2NmMyYmNkYzExZmZjNjU5In0=	2017-04-25 20:42:24.642945+00
3sdbn3budeishdq7ddblhvrg3bd8iv5p	NjJhNWU5MGM5YWQ0MGZiMjU2MWYwYmE0ZDJmZjAwMzgxNTk0Yzg1ODp7Il9hdXRoX3VzZXJfaWQiOiIzIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzN2FmZTAyNDc0ZjIwMjhiODkyYzY0NGM2NmMyYmNkYzExZmZjNjU5In0=	2017-05-10 20:57:51.170683+00
2b6ymrc21qac6s8guetkii8sqohol4jk	NTRlZWMyZTI2MWM2ZTY3OGI1NTMxMzRjYmZiMjVlZjQxMmU0MmNlMjp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI1NTUzMjY0MTY1OWQ1Mjg1ODU3YjJkODVhNWJlOGMwMWJkOTBhYWQwIn0=	2017-05-11 13:39:28.670597+00
\.


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: core_analiseimage_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_analiseimage
    ADD CONSTRAINT core_analiseimage_pkey PRIMARY KEY (id);


--
-- Name: core_analysischart_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_analysischart
    ADD CONSTRAINT core_analysischart_pkey PRIMARY KEY (id);


--
-- Name: core_expensesbyfunctions_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_expensesbyfunctions
    ADD CONSTRAINT core_expensesbyfunctions_pkey PRIMARY KEY (id);


--
-- Name: core_expensesbyfunctionsandorgans_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_expensesbyfunctionsandorgans
    ADD CONSTRAINT core_expensesbyfunctionsandorgans_pkey PRIMARY KEY (id);


--
-- Name: core_expensesbysourcesofresources_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_expensesbysourcesofresources
    ADD CONSTRAINT core_expensesbysourcesofresources_pkey PRIMARY KEY (id);


--
-- Name: core_governmentprogram_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_governmentprogram
    ADD CONSTRAINT core_governmentprogram_pkey PRIMARY KEY (id);


--
-- Name: core_organ_initials_key; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_organ
    ADD CONSTRAINT core_organ_initials_key UNIQUE (initials);


--
-- Name: core_organ_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_organ
    ADD CONSTRAINT core_organ_pkey PRIMARY KEY (id);


--
-- Name: core_period_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_period
    ADD CONSTRAINT core_period_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX auth_group_name_a6ea08ec_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX auth_user_username_6821ab7c_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: core_analiseimage_0cb91d47; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX core_analiseimage_0cb91d47 ON core_analiseimage USING btree (analise_id);


--
-- Name: core_expensesbyfunctions_period_id_89c8e39e_uniq; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX core_expensesbyfunctions_period_id_89c8e39e_uniq ON core_expensesbyfunctions USING btree (period_id);


--
-- Name: core_expensesbyfunctionsandorgans_0ee2083c; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX core_expensesbyfunctionsandorgans_0ee2083c ON core_expensesbyfunctionsandorgans USING btree (organ_id);


--
-- Name: core_expensesbyfunctionsandorgans_period_id_f19dc5c4_uniq; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX core_expensesbyfunctionsandorgans_period_id_f19dc5c4_uniq ON core_expensesbyfunctionsandorgans USING btree (period_id);


--
-- Name: core_expensesbysourcesofresources_period_id_1a9019d2_uniq; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX core_expensesbysourcesofresources_period_id_1a9019d2_uniq ON core_expensesbysourcesofresources USING btree (period_id);


--
-- Name: core_governmentprogram_b1efa79f; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX core_governmentprogram_b1efa79f ON core_governmentprogram USING btree (period_id);


--
-- Name: core_organ_initials_75c24bd5_like; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX core_organ_initials_75c24bd5_like ON core_organ USING btree (initials varchar_pattern_ops);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: sky
--

CREATE INDEX django_session_session_key_c0390e0f_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_analiseimage_analise_id_3c4858e3_fk_core_analysischart_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_analiseimage
    ADD CONSTRAINT core_analiseimage_analise_id_3c4858e3_fk_core_analysischart_id FOREIGN KEY (analise_id) REFERENCES core_analysischart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_expensesbyfunctions_period_id_89c8e39e_fk_core_period_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_expensesbyfunctions
    ADD CONSTRAINT core_expensesbyfunctions_period_id_89c8e39e_fk_core_period_id FOREIGN KEY (period_id) REFERENCES core_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_expensesbyfunctionsan_period_id_f19dc5c4_fk_core_period_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_expensesbyfunctionsandorgans
    ADD CONSTRAINT core_expensesbyfunctionsan_period_id_f19dc5c4_fk_core_period_id FOREIGN KEY (period_id) REFERENCES core_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_expensesbyfunctionsando_organ_id_08fe46ea_fk_core_organ_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_expensesbyfunctionsandorgans
    ADD CONSTRAINT core_expensesbyfunctionsando_organ_id_08fe46ea_fk_core_organ_id FOREIGN KEY (organ_id) REFERENCES core_organ(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_expensesbysourcesofre_period_id_1a9019d2_fk_core_period_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_expensesbysourcesofresources
    ADD CONSTRAINT core_expensesbysourcesofre_period_id_1a9019d2_fk_core_period_id FOREIGN KEY (period_id) REFERENCES core_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_governmentprogram_period_id_e73ea11a_fk_core_period_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY core_governmentprogram
    ADD CONSTRAINT core_governmentprogram_period_id_e73ea11a_fk_core_period_id FOREIGN KEY (period_id) REFERENCES core_period(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_content_type_id_c4bce8eb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: sky
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

